from flask import Flask, request, render_template
import pyodbc
import pandas as pd
app = Flask(__name__)



#connection to database
conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=DESKTOP-C4SI1LK;'
                      'Database=Tony;'
                      'Trusted_Connection=yes;');


#index.html
@app.route('/')
def index():
    return render_template('index.html')

@app.route("/Order_or", methods = ["GET", "POST"])
def Order():
    data1 = pd.read_sql("SELECT * FROM Order_or", conn)
    result=data1.to_html()
    return result

@app.route("/WareHouse1", methods = ["GET", "POST"])
def WareHouse():
    data2 = pd.read_sql("SELECT * FROM WareHouse1", conn)
    result=data2.to_html()
    return result

@app.route("/Delivery", methods = ["GET", "POST"])
def Delivery():
    data2 = pd.read_sql("SELECT * FROM Delivery", conn)
    result=data2.to_html()
    return result


if __name__ == '__main__':
    app.debug = True
    app.run()